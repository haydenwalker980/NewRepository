node bot.js
